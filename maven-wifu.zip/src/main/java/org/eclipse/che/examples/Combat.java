package org.eclipse.che.examples;


public class Combat {
    
Hero Stephen = new Hero();
   int Health = 100;
   int PWR = 10; 
   int Speed = 50;
    

Enemy Goomba = new Enemy();
   int EnemyHealth = 100;
   int EnemyPWR = 10;
   int EnemySpeed = 60;
   
  
   


public void WhoGoesFirst(){
    if (Speed > EnemySpeed){
        System.out.println("The Hero Goes First");
        HeroAttack();
    }
    else
    {
        System.out.println("The Enemy Goes First");
        EnemyAttack();
    }
}

//Method for when the Hero Attacks
public void HeroAttack()
{
    System.out.println("The Hero punches the enemy");
    EnemyHealth = EnemyHealth - PWR;
    System.out.println("The Enemy is hit!");
      if (EnemyHealth == 0){
        System.out.println("The enemy is dead!");
    }
    else{
    EnemyAttack();
}

}

//Method for when the Enemy Attacks
public void EnemyAttack(){
    Health = Health - EnemyPWR;
    if (Health == 0){
        System.out.println("You are dead!");
    }
    else{   
    HeroAttack();
}

}
public static void main(String[] argvs){
    WhoGoesFirst();
    
}

}
