package org.eclipse.che.examples;



public class Enemy {
    int EnemyHealth = 100;
    int EnemyPWR = 10;
    int EnemySpeed = 50;
    
    
}
