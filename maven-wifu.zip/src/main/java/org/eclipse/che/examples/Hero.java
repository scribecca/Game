package org.eclipse.che.examples;

import java.util.*;

public class Hero {
    
    Scanner in = new Scanner(System.in);
    
    //Base Traits
   int Health = 100;
   int PWR = 10;
   int Speed = 50;
    
    //Commands
    String Attack;
    String Defend;
    String Get;
    


    
    

       
        
    
    
   public static void main(String[] argvs) {
       
       
       
   }
}
