
public class VirtualWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
MyClone Stephen = new MyClone();
Dog Scruffy = new Dog();
ShoutBox ShoutBox = new ShoutBox();
Stephen.getName();
Stephen.setName();
Stephen.introduction();
Scruffy.getName();
Scruffy.setName();
Scruffy.getName();
Scruffy.Bark();
//get, set, get for test.
Scruffy.getBreed();
Scruffy.setBreed();
Scruffy.getBreed();
ShoutBox.shoutOutRandomMessage();
ShoutBox.ArrayInitialize();




	}

}
