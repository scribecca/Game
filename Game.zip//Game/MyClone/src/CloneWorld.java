
public class CloneWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyClone Stephen = new MyClone();
		Dog Scruffy = new Dog();
		ShoutBox ShoutBox = new ShoutBox();
		Stephen.setName();
		Stephen.getName();
		Stephen.introduction();
		Scruffy.setName();
		Scruffy.getName();
		Scruffy.Bark();
		Scruffy.Sit();
		Scruffy.setBreed();
		Scruffy.getBreed();
		ShoutBox.shoutOutRandomMessage();
		ShoutBox.ArrayInitialize();

	}

}
