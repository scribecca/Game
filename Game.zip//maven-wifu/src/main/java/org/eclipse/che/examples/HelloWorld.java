package org.eclipse.che.examples;

public class HelloWorld {
    public static void main(String[] argvs) {
        String a = "Che";
        System.out.println("Hello World " + a + "!");
    }
}
